angular.module('MyApp', ['ngMaterial', 'ngMessages'])
  .controller('MyCtrl', function ($scope, $http , $mdToast) {

    $scope.user = {};
    $scope.redeemData = {}
    $scope.searchPhNo;
    $scope.loadSearchButton = false;
 
var serverDetails="https://apps.viandd.in:8443/thechocolateroom/rest/userrsrc/";

    $scope.search = function (data) {
      var mobile = data;
      $http({
        method: 'get',
        url: serverDetails+'userdetMob/' + mobile,
      }).then(function (response) {
        $scope.loadSearchButton = true;
        $scope.responseStatus=response.data.message;
        if(response.data.message != null){
          $scope.user.email = response.data.message.emailId;
          $scope.user.availablecredits = response.data.message.userprofile.credits.availableCredits;
  
          $scope.user.usedcredits = response.data.message.userprofile.credits.usedCredits;
          $scope.user.name = response.data.message.fullName;
          $scope.user.phone = response.data.message.mobileNo;
  
        }else {
          alert(response.data.message );
          window.location = "index.html";
        }
      });
      $scope.loadSearchButton = false;
    }

    $scope.sendOTP = function () {
      $http({
        method: 'get',
        url: serverDetails+'userotp/' + $scope.searchPhNo,
       }).then(function (response) {
        //  console.log(response);
         $scope.otpStatus=response.status;
          if(response.data.status){
            $mdToast.show (
              $mdToast.simple()
              .textContent(response.data.message )                       
              .hideDelay(3000)
           );
          }else{
            alert(response.data.message );
           
          }
      
      });
    }

    $scope.redeem = function (data) {
        $http({
          method: 'post',
          url: serverDetails+'UserOtpValidate/' + $scope.searchPhNo,
         data:data,
           headers:{'Content-Type': 'application/json'}
         }).then(function (response) {
            if(response.data.status == true){
              //$scope.user.availablecredits = ;
              $mdToast.show (
                $mdToast.simple()
                .textContent(response.data.message )                       
                .hideDelay(3000)
             );
             $scope.user.availablecredits = response.data.data.userprofile.credits.availableCredits;
              $scope.user.usedcredits = response.data.data.userprofile.credits.usedCredits;
              
            }else if(response.data.status == false){
               console.log(response.data.message);
                $mdToast.show (
                $mdToast.simple()
                .textContent(response.data.message)                       
                .hideDelay(3000)
             );
            }
        
        });
      }
  });
